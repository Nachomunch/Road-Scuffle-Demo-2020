class Attack{
  constructor(activate, deactivate, end, width, height){
    // Creates the hitbox.
    this.shape = new createjs.Shape();
    this.shape.graphics.beginFill("#A14D4D");
    this.shape.graphics.setStrokeStyle(1);
    this.shape.graphics.beginStroke("#FF0000");
    this.shape.graphics.drawRect(0, 0, width, height);
    this.shape.alpha = .5;

    // Stores the attack frame parameters.
    this.activate = activate;
    this.deactivate = deactivate;
    this.end = end;

    // Stores the hitbox's positional data.
    this.xOffset = 0;
    this.yOffset = 0;
    this.orientation = 0;
    this.width = width;
    this.height = height;

    // Stores the attack's base-damage and effects.
    this.damage = 0;
    this.force = 0;
    this.applyIFrames = this.deactivate - this.activate;
    this.effect = null;

    stage.addChild(this.shape);
  }
}
