class Calvin extends Character{
  constructor(controller, orientation){
    super(controller, orientation);

    // Stores character specific boundaries.
    this.width = 40;
    this.height = 80;

    // Creates the hurtbox.
    this.shape = new createjs.Shape();
    this.shape.graphics.beginFill("#00C403");
    this.shape.graphics.drawRect(0, 0, this.width, this.height);

    // Allows for sub-class identification.
    this.name = "Calvin";
    this.characterColor = "#00C403";

    // Passive data.
    this.health = 1000;
    this.maxHealth = 1000;
    this.energy = 0;
    this.maxEnergy = 500;
    this.specialChanneling = false;

    stage.addChild(this.shape);
  }

  // Allows control of the character if not staggered.
  onKeyDown(key){
    if (this.stagger == 0){
      if (this.controller == 1){
        // "a" moves controller 1 left.
        if (key == 65) {this.left = true;}
        // "d" moves controller 1 right.
        if (key == 68) {this.right = true;}
        // "w" & space makes controller 1 jump.
        if (key == 32 || key == 87){
          if (this.onGround && this.inAnimation == false){
            this.velocityY -= 13;
            this.onGround = false;
          }
        }
        // "e" makes controller 1 attack-light.
        if (key == 69 && this.inAnimation == false) {
          this.lightAttack();
        }
        // "q" makes controller 1 attack-heavy.
        if (key == 81 && this.inAnimation == false) {
          this.heavyAttack();
        }
        // "r" makes controller 1 attack-special.
        if (key == 82 && (this.inAnimation == false || this.specialChanneling == true)) {
          // Toggles Calvin's special off.
          if (this.specialChanneling == true){
            this.inAnimation = false;
            stage.removeChild(this.attack.shape);
            this.attack = null;
            this.specialChanneling = false;
            return;
          }
          // Toggles Calvin's special on.
          this.specialAttack();
        }
      }

      if (this.controller == 2){
        // left arrow moves controller 2 left.
        if (key == 37) {this.left = true;}
        // right arrow moves controller 2 right.
        if (key == 39) {this.right = true;}
        // up arrow and enter makes controller 2 jump.
        if (key == 13 || key == 38){
          if (this.onGround && this.inAnimation == false){
            this.velocityY -= 13;
            this.onGround = false;
          }
        }
        // num-7 makes controller 2 attack-light.
        if (key == 36 && this.inAnimation == false) {
          this.lightAttack();
        }
        // num-9 makes controller 2 attack-heavy.
        if (key == 33 && this.inAnimation == false) {
          this.heavyAttack();
        }
        // num-forward-slash makes controller 2 attack-special.
        if (key == 111 && (this.inAnimation == false || this.specialChanneling == true)) {
          // Toggles Calvin's special off.
          if (this.specialChanneling == true){
            this.inAnimation = false;
            stage.removeChild(this.attack.shape);
            this.attack = null;
            this.specialChanneling = false;
            return;
          }
          // Toggles Calvin's special on.
          this.specialAttack();
        }
      }
    }
  }

  // Allows control of the character.
  onKeyUp(key){
    if (this.controller == 1){
      if (key == 65) {this.left = false;}
      if (key == 68) {this.right = false;}
    }

    if (this.controller == 2){
      if (key == 37) {this.left = false;}
      if (key == 39) {this.right = false;}
    }
  }

  // Creates a quick, weak attack.
  lightAttack(){
    this.attack = new Attack(5, 15, 20, 40, 50);
    this.attack.damage = 25;
    this.attack.force = 10;
    this.attack.xOffset = 15;
    this.attack.yOffset = 10;
    this.attack.orientation = this.orientation;
    this.attack.shape.x = this.shape.x + (this.width / 2) + (this.attack.xOffset * this.orientation);
    this.attack.shape.y = this.shape.y + this.attack.yOffset;
    this.attack.shape.scaleX = this.orientation;
    this.inAnimation = true;
    this.frame = 0;
  }

  // Creates a slow, strong attack.
  heavyAttack(){
    this.attack = new Attack(25, 30, 35, 160, 20);
    this.attack.damage = 75;
    this.attack.force = 20;
    this.attack.effect = new Status("slow", "tangle vine", 120, .3);
    this.attack.xOffset = -40;
    this.attack.yOffset = 65;
    this.attack.orientation = this.orientation;
    this.attack.shape.x = this.shape.x + (this.width / 2) + (this.attack.xOffset * this.orientation);
    this.attack.shape.y = this.shape.y + this.attack.yOffset;
    this.attack.shape.scaleX = this.orientation;
    this.inAnimation = true;
    this.frame = 0;
  }

  // Creates a character specific attack.
  specialAttack(){
    this.attack = new Attack(5, 6, 8, 70, 100);
    this.attack.damage = 1;
    this.attack.force = 2;
    this.attack.xOffset = -35;
    this.attack.yOffset = -20;
    this.attack.orientation = this.orientation;
    this.attack.shape.x = this.shape.x + (this.width / 2) + (this.attack.xOffset * this.orientation);
    this.attack.shape.y = this.shape.y + this.attack.yOffset;
    this.attack.shape.scaleX = this.orientation;
    this.inAnimation = true;
    this.frame = 0;

    this.specialChanneling = true;
  }

  // Manages an ability that is always active.
  passive(){
    // Tracks invulnerability.
    this.invulnerable -= 1;
    if (this.invulnerable < 0) {this.invulnerable = 0};

    // Tracks stagger.
    this.stagger -= 1;
    if (this.stagger < 0) {this.stagger = 0};

    // Tracks passive ability.
    if (this.specialChanneling == true){
      this.attack.deactivate += 1;
      this.attack.end += 1;
      if (this.energy < this.maxEnergy) {this.energy += 1;}
      this.damageMultiplier = 1 + (this.energy / this.maxEnergy);
    }

    // Tracks status effects.
    for (var i = 0; i < this.statusEffects.length; i++){
      // Removes a status if its timer reaches 0;
      if (this.statusEffects[i].time <= 0){
        this.statusEffects[i].removeStatus(this, i);
        i -= 1;
        continue;
      }
      this.statusEffects[i].time -= 1;

      // Applies Burn.
      if (this.statusEffects[i].type == "burn"){
        this.health -= this.statusEffects[i].potency;
      }
    }
  }

  // Generates the character specific resource.
  energyGeneration(combatState){
    // Calvin does not generate energy from combat.
    return;
  }
}

/*
    TODO
*/

// Balance attacks.
