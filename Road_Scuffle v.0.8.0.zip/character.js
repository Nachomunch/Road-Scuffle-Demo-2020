class Character{
  constructor(controller, orientation){
    // Stores character properties.
    this.velocityX = 0;
    this.velocityY = 0;
    this.acceleration = 1.1;
    this.movementMultiplier = 1;
    this.damageMultiplier = 1;
    this.statusEffects = [];

    // Stores movement properties.
    this.left = false;
    this.right = false;
    this.onGround = true;
    this.orientation = orientation;
    this.controller = controller;

    // Stores animation properties.
    this.attack = null;
    this.invulnerable = 0;
    this.stagger = 0;
    this.inAnimation = false;
    this.frame = 0;

    // Stores misc. data.
    this.playerColor = "";
  }
}
