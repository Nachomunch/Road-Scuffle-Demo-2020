class Claude extends Character{
  constructor(controller, orientation){
    super(controller, orientation);

    // Stores character specific boundaries.
    this.width = 40;
    this.height = 80;

    // Creates the hurtbox.
    this.shape = new createjs.Shape();
    this.shape.graphics.beginFill("#EF822E");
    this.shape.graphics.drawRect(0, 0, this.width, this.height);

    // Allows for sub-class identification.
    this.name = "Claude";
    this.characterColor = "#EF822E";

    // Passive data.
    this.health = 1000;
    this.maxHealth = 1000;
    this.energy = 0;
    this.maxEnergy = 200;
    this.specialActive = 0;

    stage.addChild(this.shape);
  }

  // Allows control of the character if not staggered.
  onKeyDown(key){
    if (this.stagger == 0){
      if (this.controller == 1){
        // "a" moves controller 1 left.
        if (key == 65) {this.left = true;}
        // "d" moves controller 1 right.
        if (key == 68) {this.right = true;}
        // "w" & space makes controller 1 jump.
        if (key == 32 || key == 87){
          if (this.onGround && this.inAnimation == false){
            this.velocityY -= 13;
            this.onGround = false;
          }
        }
        // "e" makes controller 1 attack-light.
        if (key == 69 && this.inAnimation == false) {
          this.lightAttack();
        }
        // "q" makes controller 1 attack-heavy.
        if (key == 81 && this.inAnimation == false) {
          this.heavyAttack();
        }
        // "r" makes controller 1 attack-special.
        if (key == 82 && (this.inAnimation == false && this.energy == this.maxEnergy)) {
          this.specialAttack();
        }
      }

      if (this.controller == 2){
        // left arrow moves controller 2 left.
        if (key == 37) {this.left = true;}
        // right arrow moves controller 2 right.
        if (key == 39) {this.right = true;}
        // up arrow and enter makes controller 2 jump.
        if (key == 13 || key == 38){
          if (this.onGround && this.inAnimation == false){
            this.velocityY -= 13;
            this.onGround = false;
          }
        }
        // num-7 makes controller 2 attack-light.
        if (key == 36 && this.inAnimation == false) {
          this.lightAttack();
        }
        // num-9 makes controller 2 attack-heavy.
        if (key == 33 && this.inAnimation == false) {
          this.heavyAttack();
        }
        // num-forward-slash makes controller 2 attack-special.
        if (key == 111 && (this.inAnimation == false && this.energy == this.maxEnergy)) {
          this.specialAttack();
        }
      }
    }
  }

  // Allows control of the character.
  onKeyUp(key){
    if (this.controller == 1){
      if (key == 65) {this.left = false;}
      if (key == 68) {this.right = false;}
    }

    if (this.controller == 2){
      if (key == 37) {this.left = false;}
      if (key == 39) {this.right = false;}
    }
  }

  // Creates a quick, weak attack.
  lightAttack(){
    this.attack = new Attack(10, 20, 25, 90, 30);
    this.attack.damage = 60;
    this.attack.force = 5;
    this.attack.xOffset = 10;
    this.attack.yOffset = 20;
    this.attack.orientation = this.orientation;
    this.attack.shape.x = this.shape.x + (this.width / 2) + (this.attack.xOffset * this.orientation);
    this.attack.shape.y = this.shape.y + this.attack.yOffset;
    this.attack.shape.scaleX = this.orientation;
    this.inAnimation = true;
    this.frame = 0;
  }

  // Creates a slow, strong attack.
  heavyAttack(){
    this.attack = new Attack(20, 40, 55, 145, 20);
    this.attack.damage = 150;
    this.attack.force = 20;
    this.attack.xOffset = 10;
    this.attack.yOffset = 20;
    this.attack.orientation = this.orientation;
    this.attack.shape.x = this.shape.x + (this.width / 2) + (this.attack.xOffset * this.orientation);
    this.attack.shape.y = this.shape.y + this.attack.yOffset;
    this.attack.shape.scaleX = this.orientation;
    this.inAnimation = true;
    this.frame = 0;
  }

  // Creates a character specific attack.
  specialAttack(){
    this.attack = new Attack(0, 20, 25, 200, 10);
    this.attack.damage = 50;
    this.attack.force = 10;
    this.attack.effect = new Status("burn", "dueling advance", 160, .625);
    this.attack.xOffset = -15;
    this.attack.yOffset = 20;
    this.attack.orientation = this.orientation;
    this.attack.shape.x = this.shape.x + (this.width / 2) + (this.attack.xOffset * this.orientation);
    this.attack.shape.y = this.shape.y + this.attack.yOffset;
    this.attack.shape.scaleX = this.orientation;
    this.inAnimation = true;
    this.frame = 0;

    this.velocityX += (30 * this.orientation);
    this.energy = 0;
  }

  // Manages an ability that is always active.
  passive(){
    // Tracks invulnerability.
    this.invulnerable -= 1;
    if (this.invulnerable < 0) {this.invulnerable = 0};

    // Tracks stagger.
    this.stagger -= 1;
    if (this.stagger < 0) {this.stagger = 0};

    // Tracks passive ability.
    this.specialActive -= 1;
    if (this.specialActive < 0) {this.specialActive = 0};

    // Tracks status effects.
    for (var i = 0; i < this.statusEffects.length; i++){
      // Removes a status if its timer reaches 0;
      if (this.statusEffects[i].time <= 0){
        this.statusEffects[i].removeStatus(this, i);
        i -= 1;
        continue;
      }
      this.statusEffects[i].time -= 1;

      // Applies Burn.
      if (this.statusEffects[i].type == "burn"){
        this.health -= this.statusEffects[i].potency;
      }
    }
  }

  // Generates the character specific resource.
  energyGeneration(combatState){
    if (combatState == "advantage") {
      if (this.specialActive > 0){
        this.energy += 40;
      } else {
        this.energy += 25;
      }
      this.specialActive = 120;
    }
    if (combatState == "disadvantage") {this.energy += 10}
    if (this.energy > this.maxEnergy) {this.energy = this.maxEnergy};
  }
}

/*
    TODO
*/

// Balance attacks.
