// Declares the size of the screen.
var canvasWidth = 800;
var canvasHeight = 600;

var groundHeight = 50;

function levelGeneration(){
  background = new createjs.Bitmap(loader.getResult("Background"));
  stage.addChild(background);
}
