var manifest = [
//{id: "", src: ""}
  // Background
  {id: "Background", src: "Level/background.png"},
  // HUD
  {id: "HUD", src: "Level/hud.png"}
];
