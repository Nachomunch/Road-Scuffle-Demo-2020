var canvas;
var stage;
var loader;

// Stores character select data.
var claudeSelect;
var calvinSelect;
var p1Select;
var p2Select;
var playerColors = ["#FF2D2D", "#2D2DFF"];
var characters = ["Claude", "Calvin"];
var characterInvoke = {
  Claude: function(control, orient) {return new Claude(control, orient);},
  Calvin: function(control, orient) {return new Calvin(control, orient);}
};

// Stores game states.
var gameOver = true;
var gameWon = false;

var FRICTION = .90;
var GRAVITY = .45;

// Stores players for easy iterable access.
var players = [];

/*
    Load assets
*/
function load() {
  if (manifest.length > 0) {
    loader = new createjs.LoadQueue(false);
    loader.installPlugin(createjs.Sound);
    loader.on("complete", init);
    loader.loadManifest(manifest);
  } else {
    init();
  }
}

/*
    Initialize game
*/
function init() {
  canvas = document.getElementById("canvas");
  stage = new createjs.Stage(canvas);
  canvas.width = canvasWidth;
  canvas.height = canvasHeight;

  // Creates character select.
  createCharacterSelect();

  // Registers events.
  window.onkeydown = onKeyDown;
  window.onkeyup = onKeyUp;

  // Initialize ticker.
  createjs.Ticker.setFPS(60);
  createjs.Ticker.addEventListener("tick", tick);
}

/*
    Game loop
*/
function tick(event){
  if (!gameOver && !gameWon){
    updateHUD();
    playerOrientation();
    playerMovement();
    playerBoundaries();
    playerAnimate();
    manageCombat();
    updateGameState();
  }

  // Renders stage.
  stage.update(event);
}

/*
    Key down event
*/
function onKeyDown(event) {
  var key = event.keyCode;
  if (!gameOver && !gameWon){
    player1.onKeyDown(key);
    player2.onKeyDown(key);
  } else if (gameWon){
    if (key == 13) {
      gameWon = false;
      gameOver = true;
      reset();
    }
  } else {
    /* Character select controls.*/
    // Controls player 1.
    if (key == 65) {changeSelection(p1Select, -1);}
    if (key == 68) {changeSelection(p1Select, 1);}

    // Controls player 2.
    if (key == 37) {changeSelection(p2Select, -1);}
    if (key == 39) {changeSelection(p2Select, 1);}

    // Confirms character selection.
    if (key == 13) {
      // Creates the play-field and initializes gameplay.
      stage.removeAllChildren();
      levelGeneration();
      createPlayers();
      createHUD();
      gameOver = false;
    }
  }
}

/*
    Key up event
*/
function onKeyUp(event) {
  if (!gameOver){
    player1.onKeyUp(event.keyCode);
    player2.onKeyUp(event.keyCode);
  }
}

/*
    Init functions
*/
function createCharacterSelect(){
  // Creates the prompt to select a character.
  selectText = new createjs.Text("Select a character.", "60px Arial", "#FFFFFF");
  selectText.x = (canvasWidth - selectText.getBounds().width) / 2;
  selectText.y = 20;
  stage.addChild(selectText);

  // Creates the visual for selecting Claude.
  claudeSelect = new createjs.Shape();
  claudeSelect.width = 200;
  claudeSelect.height = 200;
  claudeSelect.graphics.beginFill("#EF822E");
  claudeSelect.graphics.drawRect(0, 0, claudeSelect.width, claudeSelect.height);
  stage.addChild(claudeSelect);
  claudeSelect.x = (canvas.width - (claudeSelect.width * 3)) / 2;
  claudeSelect.y = 250;

  // Creates the visual for selecting Calvin.
  calvinSelect = new createjs.Shape();
  calvinSelect.width = 200;
  calvinSelect.height = 200;
  calvinSelect.graphics.beginFill("#00C403");
  calvinSelect.graphics.drawRect(0, 0, calvinSelect.width, calvinSelect.height);
  stage.addChild(calvinSelect);
  calvinSelect.x = ((canvas.width - (calvinSelect.width * 3)) / 2) + calvinSelect.width * 2;
  calvinSelect.y = 250;

  // Creates the visual for player 1's selection.
  p1Select = new createjs.Shape();
  p1Select.width = 50;
  p1Select.height = 50;
  p1Select.graphics.beginFill(playerColors[0]);
  p1Select.graphics.drawRect(0, 0, p1Select.width, p1Select.height);
  stage.addChild(p1Select);
  p1Select.x = ((claudeSelect.width - (p1Select.width * 3)) / 2) + claudeSelect.x;
  p1Select.y = 175;
  p1Select.originX = p1Select.x;
  p1Select.originY = p1Select.y;
  p1Select.id = 0;

  // Creates the visual for player 2's selection.
  p2Select = new createjs.Shape();
  p2Select.width = 50;
  p2Select.height = 50;
  p2Select.graphics.beginFill(playerColors[1]);
  p2Select.graphics.drawRect(0, 0, p1Select.width, p1Select.height);
  stage.addChild(p2Select);
  p2Select.x = ((calvinSelect.width - (p2Select.width * 3)) / 2) + p2Select.width * 2 + claudeSelect.x;
  p2Select.y = 175;
  p2Select.originX = p2Select.x;
  p2Select.originY = p2Select.y;
  p2Select.id = 0;
}

// Places player characters on the play-field.
function createPlayers(){
  // Creates and spawns player 1.
  player1 = characterInvoke[characters[p1Select.id]](1, 1);
  player1.shape.x = canvas.width / 3 - (player1.width / 2);
  player1.shape.y = canvas.height - groundHeight - player1.height - 1;
  player1.playerColor = playerColors[0];

  // Creates and spawns player 2.
  player2 = characterInvoke[characters[p2Select.id]](2, -1);
  player2.shape.x = (canvas.width / 3) * 2 - (player2.width / 2);
  player2.shape.y = canvas.height - groundHeight - player2.height - 1;
  player2.playerColor = playerColors[1];

  players = [player1, player2];
}

// Places the heads up display on the screen.
function createHUD(){
  // Displays player1's health.
  player1Health = new createjs.Shape();
  player1Health.graphics.beginFill("#FF2D2D");
  player1Health.graphics.drawRect(0, 0, 300, 15);
  stage.addChild(player1Health);
  player1Health.x = 9;
  player1Health.y = 9;
  player1Health.originX = player1Health.x;

  // Displays player1's energy.
  player1Energy = new createjs.Shape();
  player1Energy.graphics.beginFill("#2D2DFF");
  player1Energy.graphics.drawRect(0, 0, 150, 9);
  stage.addChild(player1Energy);
  player1Energy.x = -144;
  player1Energy.y = 36;
  player1Energy.originX = player1Energy.x;

  // Displays player1's border.
  player1HUD = new createjs.Bitmap(loader.getResult("HUD"));
  stage.addChild(player1HUD);
  player1HUD.x = 0;
  player1HUD.y = 0;

  // Displays player2's health.
  player2Health = new createjs.Shape();
  player2Health.graphics.beginFill("#FF2D2D");
  player2Health.graphics.drawRect(0, 0, 300, 15);
  stage.addChild(player2Health);
  player2Health.x = 491;
  player2Health.y = 9;
  player2Health.originX = player2Health.x;

  // Displays player2's energy.
  player2Energy = new createjs.Shape();
  player2Energy.graphics.beginFill("#2D2DFF");
  player2Energy.graphics.drawRect(0, 0, 150, 9);
  stage.addChild(player2Energy);
  player2Energy.x = 794;
  player2Energy.y = 36;
  player2Energy.originX = player2Energy.x;

  // Displays player2's border.
  player2HUD = new createjs.Bitmap(loader.getResult("HUD"));
  stage.addChild(player2HUD);
  player2HUD.x = canvas.width;
  player2HUD.y = 0;
  player2HUD.scaleX = -1;
}

/*
    Gameloop functions
*/
// Moves players from one position to another.
function playerMovement(){
  for (var i = 0; i < players.length; i++){
    var direction = players[i].velocityX * players[i].orientation;
    // Slows player movement when moving backwards
    if (direction < 0){
      playerMoveBackward(players[i]);
    } else {
      playerMoveForward(players[i]);
    }

    // Changes a player's horizontal position.
    players[i].shape.x += players[i].velocityX;
    if (players[i].attack != null){
      players[i].attack.shape.x = players[i].shape.x + (players[i].width / 2) + (players[i].attack.xOffset * players[i].attack.orientation);
    }
    players[i].velocityX *= FRICTION;

    // Changes a player's vertical position.
    players[i].shape.y += players[i].velocityY;
    if (players[i].attack != null){
      players[i].attack.shape.y = players[i].shape.y + players[i].attack.yOffset;
    }
    players[i].velocityY += GRAVITY;
  }
}

// Manages players' forward velocity.
function playerMoveForward(player){
  if (player.inAnimation == false){
    if (player.left){
      player.velocityX -= (player.acceleration * player.movementMultiplier);
    }
    if (player.right){
      player.velocityX += (player.acceleration * player.movementMultiplier);
    }
  }
}

// Manages players' backward velocity.
function playerMoveBackward(player){
  if (player.inAnimation == false){
    if (player.left){
      player.velocityX -= ((player.acceleration / 1.5) * player.movementMultiplier);
    }
    if (player.right){
      player.velocityX += ((player.acceleration / 1.5) * player.movementMultiplier);
    }
  }
}

// Prevents players from leaving the play-field.
function playerBoundaries(){
  for (var i = 0; i < players.length; i++){
    // Stops players at the left boundary.
    if (players[i].shape.x < 0){
      players[i].shape.x = 0;
      players[i].velocityX = 0;
    }
    // Stops players at the right boundary.
    if (players[i].shape.x + players[i].width > canvas.width){
      players[i].shape.x = canvas.width - players[i].width;
      players[i].velocityX = 0;
    }
    // Stops players from falling below the ground.
    if (players[i].shape.y + players[i].height > canvasHeight - groundHeight){
      players[i].shape.y = canvasHeight - groundHeight - players[i].height;
      players[i].velocityY = 0;
      players[i].onGround = true;
    }
  }
}

// Determines the direction a character is facing.
function playerOrientation(){
  var p1Mid = player1.width / 2;
  var p2Mid = player2.width / 2;
  // Checks if player1 is to the right of player2.
  if (player1.orientation == 1){
    if (player1.shape.x + p1Mid > player2.shape.x + p2Mid){
      for (var i = 0; i < players.length; i++){
        players[i].orientation *= -1;
      }
    }
  // Checks if player1 is to the left of player2.
  } else {
    if (player2.shape.x + p2Mid > player1.shape.x + p1Mid){
      for (var i = 0; i < players.length; i++){
        players[i].orientation *= -1;
      }
    }
  }
}

// Detects hits and manages the stages of attacks, buffs, and debuffs.
function manageCombat(){
  for (var i = 0, j = players.length - 1; i < players.length; i++, j--){
    // Keeps passive effects running constantly.
    players[i].passive();
    // Player attacks always trigger an animation.
    if (players[i].inAnimation == true){
      // Player's attack has begun.
      if (players[j].invulnerable == 0){
        if (players[i].frame >= players[i].attack.activate && players[i].frame < players[i].attack.deactivate){
          if (hitDetect(players[i].attack, players[j]) == true){
            if (players[i].attack.effect != null){
              players[i].attack.effect.addStatus(players[j]);
            }
            players[j].health -= players[i].attack.damage * players[i].damageMultiplier;
            players[i].energyGeneration("advantage");
            players[j].energyGeneration("disadvantage");
            players[j].invulnerable = players[i].attack.applyIFrames;
            applyStagger(players[j], players[i].attack.force);
          }
        }
      }
      // Player's attack has ended.
      if (players[i].frame == players[i].attack.end){
        players[i].inAnimation = false;
        stage.removeChild(players[i].attack.shape);
        players[i].attack = null;
      }
    }
  }
}

// Manages the visual display of each character.
function playerAnimate(){
  for (var i = 0; i < players.length; i++){
    if (players[i].inAnimation == true){
      players[i].frame += 1;

      // Manages visuals for hitboxes.
      if (players[i].frame == players[i].attack.activate){
        width = players[i].attack.width;
        height = players[i].attack.height;
        stage.removeChild(players[i].attack.shape);
        players[i].attack.shape = new createjs.Shape();
        players[i].attack.shape.graphics.beginFill("#63A14D");
        players[i].attack.shape.graphics.setStrokeStyle(1);
        players[i].attack.shape.graphics.beginStroke("#43FF00");
        players[i].attack.shape.graphics.drawRect(0, 0, width, height);
        players[i].attack.shape.alpha = .5;
        stage.addChild(players[i].attack.shape);
        players[i].attack.shape.x = players[i].shape.x + (players[i].width / 2) + (players[i].attack.xOffset * players[i].attack.orientation);
        players[i].attack.shape.y = players[i].shape.y + players[i].attack.yOffset;
        players[i].attack.shape.scaleX = players[i].orientation;
        players[i].attack.orientation = players[i].orientation;
      }
      if (players[i].frame == players[i].attack.deactivate){
        width = players[i].attack.width;
        height = players[i].attack.height;
        stage.removeChild(players[i].attack.shape);
        players[i].attack.shape = new createjs.Shape();
        players[i].attack.shape.graphics.beginFill("#A14D4D");
        players[i].attack.shape.graphics.setStrokeStyle(1);
        players[i].attack.shape.graphics.beginStroke("#FF0000");
        players[i].attack.shape.graphics.drawRect(0, 0, width, height);
        players[i].attack.shape.alpha = .5;
        stage.addChild(players[i].attack.shape);
        players[i].attack.shape.x = players[i].shape.x + (players[i].width / 2) + (players[i].attack.xOffset * players[i].attack.orientation);
        players[i].attack.shape.y = players[i].shape.y + players[i].attack.yOffset;
        players[i].attack.shape.scaleX = players[i].orientation;
        players[i].attack.orientation = players[i].orientation;
      }
    }
  }
}

// Refreshes the heads up display.
function updateHUD(){
  player1Health.x = player1Health.originX - (((players[0].maxHealth - players[0].health) / players[0].maxHealth) * 300);
  player1Energy.x = player1Energy.originX + ((players[0].energy / players[0].maxEnergy) * 150);
  player2Health.x = player2Health.originX + (((players[1].maxHealth - players[1].health) / players[1].maxHealth) * 300);
  player2Energy.x = player2Energy.originX - ((players[1].energy / players[1].maxEnergy) * 150);
}

// Manages game states.
function updateGameState(){
  for (var i = 0, j = players.length - 1; i < players.length; i++, j--){
    // Checks for the win state (player death).
    if (players[i].health <= 0){
      gameWon = true;
      stage.removeAllChildren();

      winnerText = new createjs.Text("Winner:", "120px Arial", "#FFFFFF");
      winnerText.x = (canvasWidth - winnerText.getBounds().width) / 2;
      winnerText.y = 20;
      stage.addChild(winnerText);

      playerWinText = new createjs.Text("Player " + players[j].controller, "80px Arial", players[j].playerColor);
      playerWinText.x = (canvasWidth - playerWinText.getBounds().width) / 2;
      playerWinText.y = winnerText.y + winnerText.getBounds().height + 20;
      stage.addChild(playerWinText);

      // Placeholder character (TODO: replace with sprite))
      characterWin = new createjs.Shape();
      characterWin.graphics.beginFill(players[j].characterColor);
      characterWin.graphics.drawRect(0, 0, 100, 100);
      stage.addChild(characterWin);
      characterWin.x = (canvasWidth / 2) - 50;
      characterWin.y = (canvasHeight / 3) * 2;
    }
  }
}

/*
    Misc. functions.
*/

function changeSelection(player, idChange){
  // Changes the selection id to the newly selected character.
  player.id += idChange;
  if (player.id == characters.length) {player.id = 0;}
  if (player.id == -1) {player.id = characters.length - 1;}

  // Moves the player's visual selection to the newly selected character.
  player.x = player.originX;
  player.x += player.id * (claudeSelect.width * 2);
}

// Detects if a hitbox overlaps a hurtbox.
function hitDetect(attack, target){
  // Shortens variable names.
  var hitbox = attack.shape;
  var hurtbox = target.shape;
  var width = attack.width * attack.orientation;
  var height = attack.height;

  // Checks hitbox origin.
  if (hitbox.x >= hurtbox.x && hitbox.x <= hurtbox.x + target.width &&
  hitbox.y >= hurtbox.y && hitbox.y <= hurtbox.y + target.height){
    return true;
  }

  // Checks hitbox with y at origin and x at width.
  if (hitbox.x + width >= hurtbox.x && hitbox.x + width <= hurtbox.x + target.width &&
  hitbox.y >= hurtbox.y && hitbox.y <= hurtbox.y + target.height){
    return true;
  }

  // Checks hitbox with y at height and x at origin.
  if (hitbox.x >= hurtbox.x && hitbox.x <= hurtbox.x + target.width &&
  hitbox.y + height >= hurtbox.y && hitbox.y + height <= hurtbox.y + target.height){
    return true;
  }

  // Checks hitbox with y at height and x at width.
  if (hitbox.x + width >= hurtbox.x && hitbox.x + width <= hurtbox.x + target.width &&
  hitbox.y + height >= hurtbox.y && hitbox.y + height <= hurtbox.y + target.height){
    return true;
  }

  // Checks for hurtbox and hitbox overlap.
  if ((hurtbox.x >= hitbox.x || hurtbox.x >= hitbox.x + width) &&
  (hurtbox.x + target.width <= hitbox.x || hurtbox.x + target.width <= hitbox.x + width) &&
  (hurtbox.y <= hitbox.y + height && hurtbox.y + target.height >= hitbox.y)){
    return true;
  }

  return false;
}

// Cancels attacks and applies knockback.
function applyStagger(player, force){
  if (player.inAnimation == true){
    player.inAnimation = false;
    stage.removeChild(player.attack.shape);
    player.attack = null;
  }

  if (player.name == "Calvin"){
    player.specialChanneling = false;
  }

  player.stagger = force;
  player.velocityX += (force * -player.orientation);
  player.left = false;
  player.right = false;
}

// Resets the game.
function reset(){
  stage.removeAllChildren();
  init();
}

/*
    TODO
*/

// Please, add real comments.
// Remove temporary win message. (add sprites) (remove characterColor)
// Improve HUD (new colors) (change HUD layering)
// Optimize. (more functions, remove magic numbers, improve readability)
