class Status{
  constructor(type, name, time, potency){
    // Type is a string that represents what the status does.
    this.type = type;
    // Name references the status's origin, preventing more than one instance.
    this.name = name;
    // Time tracks the remaining frames that the status is active.
    this.time = time;
    // Potency is the power of the status effect.
    this.potency = potency;
    /* Status Chart:
    type = burn, potency = 0 ~ infinity (damage tick)
    type = slow, potency = 0 ~ 1 (percentage)
    */
  }

  // Adds a status if it is not already applied.
  addStatus(character){
    for (var i = 0; i < character.statusEffects.length; i++){
      if (this.name == character.statusEffects[i].name){
        return;
      }
    }

    //Adds slow effect.
    if (this.type == "slow"){
      character.movementMultiplier -= this.potency;
    }
    character.statusEffects.push(this);
  }

  // Removes a status effect at a given index.
  removeStatus(character, index){
    if (this.type == "slow"){
      character.movementMultiplier += this.potency;
    }

    character.statusEffects.splice(index, 1);
  }
}
